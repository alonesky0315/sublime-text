# BracketHighlighter

Welcome to BracketHighlighter!  For a quick start guide, please go to  
`Preferences->Package Settings->BracketHighlighter->Quick Start Guide`.
