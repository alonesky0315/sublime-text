# BracketHighlighter 2.27.0

New release!

Please see `Preferences->Package Settings->BracketHighlighter->Changelog`  
for more info about the release.
