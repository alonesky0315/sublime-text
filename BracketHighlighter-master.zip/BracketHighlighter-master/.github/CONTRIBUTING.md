Please follow this link to see Contributing &amp; Support documentation: http://facelessuser.github.io/BracketHighlighter/contributing/.
